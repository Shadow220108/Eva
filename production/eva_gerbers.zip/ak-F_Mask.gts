G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*
G04 #@! TF.CreationDate,2026-09-30T16:40:59+05:30*
G04 #@! TF.ProjectId,ak,616b2e6b-6963-4616-945f-706362585858,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-09-30 16:40:59*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
%AMRotRect*
0 Rectangle, with rotation*
0 The origin of the aperture is its center*
0 $1 length*
0 $2 width*
0 $3 Rotation angle, in degrees counterclockwise*
0 Add horizontal line*
21,1,$1,$2,0,0,$3*%
G04 Aperture macros list end*
%ADD10C,5.000000*%
%ADD11RotRect,0.800000X0.800000X44.530000*%
%ADD12RotRect,0.800000X0.800000X216.160000*%
%ADD13RotRect,1.000000X1.400000X45.000000*%
%ADD14RotRect,0.400000X0.220000X225.000000*%
%ADD15RotRect,0.400000X0.220000X135.000000*%
%ADD16RotRect,0.400000X0.280000X135.000000*%
%ADD17RoundRect,0.250000X-0.503814X-0.132583X-0.132583X-0.503814X0.503814X0.132583X0.132583X0.503814X0*%
%ADD18RoundRect,0.225000X-0.335876X-0.017678X-0.017678X-0.335876X0.335876X0.017678X0.017678X0.335876X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,REF\u002A\u002A*
X240700000Y-73175000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,AE1*
X204191299Y-88386201D03*
D12*
X208338099Y-89598501D03*
G04 #@! TD*
D13*
G04 #@! TO.C,LED1*
X196450000Y-80100000D03*
X197934924Y-78615076D03*
G04 #@! TD*
D14*
G04 #@! TO.C,U1*
X201200736Y-85449264D03*
D15*
X200847183Y-84954289D03*
X201200736Y-84600736D03*
X201554289Y-84247183D03*
D14*
X202049264Y-84600736D03*
D15*
X202402817Y-85095711D03*
X202049264Y-85449264D03*
D16*
X201695711Y-85802817D03*
G04 #@! TD*
D17*
G04 #@! TO.C,R1*
X198104765Y-81654765D03*
X199395235Y-82945235D03*
G04 #@! TD*
D18*
G04 #@! TO.C,C1*
X202953984Y-82528984D03*
X204050000Y-83625000D03*
G04 #@! TD*
M02*
